var Service = require('egg').Service;
class WaService extends Service {
  
}
module.exports = WaService;